Ce répertoire contient les éléments du code avant le choix d'utilisation de PyGame plutôt que Tkinter.
